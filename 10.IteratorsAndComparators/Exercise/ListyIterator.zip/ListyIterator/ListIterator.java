package JavaAdvanced.IteratorsAndComparators.Exercise.ListyIterator;

import java.util.ArrayList;
import java.util.List;

public class ListIterator {
    private List<String> stringList = new ArrayList<>();
    private int currentIndex;

    public ListIterator(List<String> input) {
        this.stringList = input;
    }

    public boolean Move() {
        if (currentIndex < stringList.size() - 1) {
            currentIndex++;
            return true;
        }
        return false;
    }

    public boolean HasNext() {
        return currentIndex + 1 < stringList.size();
    }

    public void Print() {
        if (stringList.isEmpty()) {
            throw new IllegalStateException("Invalid Operation!");
        }
        System.out.println(stringList.get(currentIndex));
    }
}
