package JavaAdvanced.Generics.Lab;

public class Main {
    public static void main(String[] args) {

        Jar<Integer> integerJar = new Jar<>();
        integerJar.add(5);
        integerJar.add(3);
        integerJar.add(4);


    }
}
